'MB Alien Report 72' Font by ModBlackmoon
Created with Photoshop.
Incl. English, European letters. Russian version probably will be added with font updates.

Free for personal and commercial use. You may not modify this font.
Sharing this font on the other web-sites is forbidden.

All Rights Reserved. May 2010

http://www.modblackmoon.eu.mn/
http://modblackmoon.narod.ru/