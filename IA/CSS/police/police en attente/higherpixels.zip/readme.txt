Higher Pixels — version 1.11
by Max Infeld / Xerographer Fonts
Copyright (c) Max Infeld. All rights reserved.

WHAT'S NEW
v1.11 (October 2026): added Western European (Latin-1) and Central European (Latin Extended-A) letters,
curly quotes, dashes and currency symbols (€ £ ¥ © ® ™), accent positioning. 326 glyphs (was 72).
Languages now covered include English, French, German, Spanish, Portuguese, Italian, Dutch, the Nordic languages, Polish, Czech, Slovak, Hungarian, Croatian, Slovenian, Romanian, Turkish and more.
Try it: Café résumé naïve · Straße Größe · Cześć Łódź · Žluťoučký kůň

PERSONAL USE
Personal, non-commercial use is donationware. A donation to the designer is
appreciated (use the "Donate to author" button on DaFont).

COMMERCIAL USE
Commercial use requires a license:
  US$95 per typeface, or US$65,000 for the entire Xerographer catalog,
  one licensee.
License online:  https://fonts.grok.me/font/higherpixels
Or write to:     maxinfeld@gmail.com

You may not resell, redistribute, sublicense or share the font files, or
modify the typeface or create derivative fonts, without written permission.

More fonts: https://fonts.grok.me  ·  https://www.dafont.com/max-infeld.d3584
Source files: https://github.com/maximusmaximus/xerographer-fonts
